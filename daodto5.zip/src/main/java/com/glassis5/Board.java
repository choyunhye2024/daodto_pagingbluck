package com.glassis5;

public class Board {

	static public final int LIST_AMOUNT = 5;
	static public final int PAGE_LINK_AMOUNT = 3;

}
